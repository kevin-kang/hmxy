require(['js/module/util', 'js/module/mfontsize'], function(util) {
    var $doc = $(document),
        $win = $(window),
        $page2 = $('.page-2'),
        $ipt = $('.ipt'),
        $iptBtn = $('.ipt-btn'),
        $keyboard = $('.keyboard'),
        $delBtn = $('.del'),
        $okBtn = $('.ok'),
        $keyboardKey = $keyboard.find('li').not('.del, .ok'),
        userInfor = JSON.parse(localStorage.getItem('iheima.com'));

    function showKeyboard() {
        if ($keyboard.css('display') != 'block' && $ipt.text() == '手机号') {
            $ipt.data('dft-val', $ipt.text()).text('').addClass('cur');
        }
        $keyboard.addClass('isshow');
    }

    function hideKeyboard() {
        $keyboard.removeClass('isshow');
        if (util.isNull($ipt.text())) {
            $ipt.text($ipt.data('dft-val')).removeClass('cur');
        }
    }

    function changeInputValue(e) {
        var $target = $(this),
            keyValue = $target.text(),
            iptValue = $ipt.text(),
            newValue = iptValue + keyValue;

        $ipt.text(newValue);
    }

    function delInputValue(e) {
        var $target = $(this),
            iptValueLen = $ipt.text().length - 1,
            newValue = $ipt.text().slice(0, iptValueLen);

        $ipt.text(newValue);
    }

    // function verifyPhone(e) { //验证手机号
    //     var phone = $ipt.text();

    //     if (!/^(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$/g.test(phone)) {
    //         alert('手机号错误！');
    //     }
    // }

    function addPhone() { //提交手机号

        if (!/^(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$/g.test($ipt.text())) {
            alert('手机号错误！');
            return false;
        }

        $.ajax({
            url: 'http://app.iheima.com/?app=ihmactivity&controller=h5&action=activitymobile',
            type: 'GET',
            dataType: 'jsonp',
            jsonp: 'jsoncallback',
            data: {
                openid: userInfor.openid,
                mobile: $ipt.text()
            },
            success: function(res) {
                if (res == '1000') {
                    hideKeyboard();
                    location.href = 'list.html' //列表页
                } else {
                    alert('参数错误');
                }
            }
        });
    }

    $iptBtn.on('touchend', addPhone); //提交
    $ipt.on('touchend', showKeyboard); //输入框
    $keyboardKey.on('touchend', changeInputValue); //键盘按键
    $okBtn.on('touchend', hideKeyboard); //完成按键
    $delBtn.on('touchend', delInputValue); //删除按键

    history.replaceState(null, '首页', 'http://app.iheima.com/special/teachersday/');

    function onBridgeReady() {
        var mainTitle = "黑马学院——全球第一的创业与投资实战商学院",
            mainDesc = "黑马学院——全球第一的创业与投资实战商学院",
            mainURL = location.href,
            mainImgUrl = " ";
        //mainImgUrl= "http://hmy.iheima.com/zhuanti/hmyEleven/sm_logo.jpg";

        //转发朋友圈
        WeixinJSBridge.on("menu:share:timeline", function(e) {
            var data = {
                img_url: mainImgUrl,
                img_width: "120",
                img_height: "120",
                link: mainURL,
                //desc这个属性要加上，虽然不会显示，但是不加暂时会导致无法转发至朋友圈，
                desc: mainDesc,
                title: mainTitle
            };
            WeixinJSBridge.invoke("shareTimeline", data, function(res) {
                WeixinJSBridge.log(res.err_msg)
            });
        });
        //同步到微博
        WeixinJSBridge.on("menu:share:weibo", function() {
            WeixinJSBridge.invoke("shareWeibo", {
                "content": mainDesc,
                "url": mainURL
            }, function(res) {
                WeixinJSBridge.log(res.err_msg);
            });
        });
        //分享给朋友
        WeixinJSBridge.on('menu:share:appmessage', function(argv) {
            WeixinJSBridge.invoke("sendAppMessage", {
                img_url: mainImgUrl,
                img_width: "120",
                img_height: "120",
                link: mainURL,
                desc: mainDesc,
                title: mainTitle
            }, function(res) {
                WeixinJSBridge.log(res.err_msg)
            });
        });
    };
    //执行
    document.addEventListener('WeixinJSBridgeReady', function() {
        onBridgeReady();
    });

});