require(['js/module/util', 'js/module/login', 'js/module/mfontsize'], function(util, login) {
    var imgArr = [
            'css/img/bg.jpg',
            'css/img/img-1.png',
            'css/img/img-2.png',
            'css/img/img-3.png',
            'css/img/img-4.png',
            'css/img/img-5.png',
            'css/img/txt-1.png',
            'css/img/txt-1-2.png'
        ],
        imgArrPhone = [
            'css/img/bg.jpg',
            'css/img/txt-2.png',
            'css/img/txt-3.png',
            'css/img/img-6.png',
            'css/img/del.png',
        ],
        imagesLoader = imagesLoader2 = null,
        $page1 = $('.page-1'),
        WXcode = util.query('code'),
        baseUrl = encodeURIComponent('http://www.iheima.com/special/teachersday/'),
        url = 'http://app.iheima.com/?app=ihmactivity&controller=h5&action=activityauthbackhome';

    if(!WXcode){
        location.href = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxe7d51503312986a8&redirect_uri='+ baseUrl +'&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect';
        return false;
    }

    WXcode && login(url, WXcode); //微信授权

    imagesLoader = new util.ImagesLoader(imgArr);
    imagesLoader.loaded();
    imagesLoader.allcompletes(function() {
        $page1.addClass('anim');
        $page1.find('.img-5').on('webkitAnimationEnd animationEnd', goPhone);
        imagesLoader2 = new util.ImagesLoader(imgArrPhone);
        imagesLoader2.loaded();
    });

    function goPhone(e) {
        setTimeout(function() {
            location.href = 'phone.html'
        }, 3000);
    }

    $page1.on('click', goPhone);

});